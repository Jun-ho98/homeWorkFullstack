import React, { useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import useProduct from '../hooks/useProduct';
import ProductDetailContent from '../components/detail/ProductDetailContent';
import ProductDetailText from '../components/detail/ProductDetailText';
import { deleteById } from '../api/productApi';

function ProductDetailPage() {
  const { id } = useParams();
  const { loading, error, fetchProductVoById } = useProduct();
  const navigate = useNavigate();

  useEffect(() => {
    fetchProductVoById(id);
  }, [id]);

  if (loading) return <h1>로딩중 . . .</h1>;
  if (error) return <h1>에러 발생 ㅠ</h1>;

  return (
    <>
      <ProductDetailText />
      <ProductDetailContent />
      <button
        onClick={() => {
          navigate(`/product/edit/${id}`);
        }}
      >
        수정
      </button>
      <button
        onClick={async () => {
          await deleteById(id);
          alert('삭제 완료');
          navigate(`/product/list`);
        }}
      >
        삭제
      </button>
    </>
  );
}

export default ProductDetailPage;
