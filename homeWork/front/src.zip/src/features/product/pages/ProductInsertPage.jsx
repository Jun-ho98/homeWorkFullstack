import React, { useState } from 'react';
import { save } from '../api/productApi';
import { useNavigate } from 'react-router-dom';

function ProductInsertPage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    price: '',
  });

  async function handleSubmit(evt) {
    evt.preventDefault();
    await save(formData);
    alert('등록 완료');
    navigate(`/product/list`);
  }

  function handleChange(evt) {
    setFormData({ ...formData, [evt.target.name]: evt.target.value });
  }

  return (
    <>
      <h1>상품 등록</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="상품 이름"
          value={formData.name}
          onChange={handleChange}
        />
        <input
          type="number"
          name="price"
          placeholder="가격"
          value={formData.price}
          onChange={handleChange}
        />
        <input type="submit" value={'등록'} />
      </form>
    </>
  );
}

export default ProductInsertPage;
