import React from 'react';

function ProductListText() {
  return (
    <>
      <h1>상품 목록</h1>
    </>
  );
}

export default ProductListText;
