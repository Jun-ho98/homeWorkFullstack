import React from 'react';
import useProduct from '../../hooks/useProduct';
import { useNavigate } from 'react-router-dom';

function ProductListTable() {
  const { voList } = useProduct();
  const navigate = useNavigate();

  return (
    <>
      <table>
        <thead>
          <tr>
            <th>상품 번호</th>
            <th>상품 이름</th>
            <th>가격</th>
          </tr>
        </thead>
        <tbody>
          {voList.map((vo) => {
            return (
              <tr
                key={vo.id}
                onClick={() => {
                  navigate(`/product/detail/${vo.id}`);
                }}
              >
                <td>{vo.id}</td>
                <td>{vo.name}</td>
                <td>{vo.price}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </>
  );
}

export default ProductListTable;
