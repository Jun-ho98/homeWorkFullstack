import React from 'react';
import useProduct from '../../hooks/useProduct';

function ProductDetailContent() {
  const { vo } = useProduct();

  return (
    <>
      <div>
        <h3>번호 : {vo.id}</h3>
        <h3>이름 : {vo.name}</h3>
        <h3>가격 : {vo.price}</h3>
        <h3>작성일시 : {vo.createdAt}</h3>
        <h3>수정일시 : {vo.modifiedAt}</h3>
      </div>
    </>
  );
}

export default ProductDetailContent;
