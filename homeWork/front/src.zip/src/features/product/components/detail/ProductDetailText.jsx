import React from 'react';

function ProductDetailText() {
  return (
    <>
      <h1>상품 상세</h1>
    </>
  );
}

export default ProductDetailText;
