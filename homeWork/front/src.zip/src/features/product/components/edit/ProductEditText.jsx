import React from 'react';

function ProductEditText() {
  return (
    <>
      <h1>상품 수정</h1>
    </>
  );
}

export default ProductEditText;
