import React, { useState } from 'react';
import useProduct from '../../hooks/useProduct';
import { updateNameAndPriceById } from '../../api/productApi';
import { useNavigate } from 'react-router-dom';

function ProductEditForm() {
  const { vo } = useProduct();
  const navi = useNavigate();

  const [formData, setFormData] = useState({
    id: vo.id,
    name: vo.name,
    price: vo.price,
  });

  async function handleSubmit(evt) {
    evt.preventDefault();
    await updateNameAndPriceById(formData);
    alert('수정성공');
    navi(`/product/detail/${vo.id}`);
  }

  function handleChange(evt) {
    setFormData({ ...formData, [evt.target.name]: evt.target.value });
  }

  return (
    <>
      <form onSubmit={handleSubmit}>
        <h3>번호 : {vo.id}</h3>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
        />
        <input
          type="number"
          name="price"
          value={formData.price}
          onChange={handleChange}
        />
        <input type="submit" value={'수정'} />
      </form>
    </>
  );
}

export default ProductEditForm;
